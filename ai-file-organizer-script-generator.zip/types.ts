
export type OrganizationPlan = {
  [folderName: string]: string[];
};

export type ScriptType = 'bash' | 'powershell';
   